+++
title = "Getting started"
description = ""
weight = 1
+++

{{< lead >}}
Get started with Ace docs, the easy way to generate a static website for your project's documentation. 
{{< /lead >}}

Installation and configuration is easy and can be easily applied to any project. No need to be dependent on Python, Ruby or Java. Hugo runs from a simple binary and works through the command line.
Explore the following pages to learn how to build awesome documentation for your project using Ace.

{{< childpages >}}